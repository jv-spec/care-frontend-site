"use client"

import Image from "next/image"
import { AnimatedLogo } from "@/components/animated-logo"
import { MobileNav } from "@/components/mobile-nav"
import { LanguageSwitcher } from "@/components/language-switcher"
import { SmartTypewriter } from "@/components/smart-typewriter"
import { useLanguage } from "@/contexts/LanguageContext"
import { translations } from "@/translations"

export default function Home() {
  const { language } = useLanguage()
  const t = translations[language]

  return (
    <main className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-background z-50 border-b border-border">
        <div className="container mx-auto px-6 py-5">
          <div className="flex items-center justify-between">
            <a href="#" className="cursor-pointer">
              <img src="/images/ncare-logo-header.svg" alt="nCare" className="h-8 md:h-9 w-auto dark:brightness-0 dark:invert" />
            </a>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#sobre" className="text-foreground hover:text-foreground/70 transition-colors">
                {t.nav.about}
              </a>
              <a href="#metodo" className="text-foreground hover:text-foreground/70 transition-colors">
                {t.nav.method}
              </a>
              <a href="#principios" className="text-foreground hover:text-foreground/70 transition-colors">
                {t.nav.principles}
              </a>
              <a href="#fundadores" className="text-foreground hover:text-foreground/70 transition-colors">
                {t.nav.team}
              </a>
              <LanguageSwitcher />
            </div>

            {/* Mobile Menu */}
            <MobileNav />
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-background text-foreground min-h-screen flex items-center pt-20">
        <div className="container mx-auto px-6 lg:px-10 py-12 md:py-20">
          <div className="max-w-[900px]">
            <SmartTypewriter
              fixedTitle={t.hero.title1}
              phrases={t.hero.phrases}
              typingDelay={100}
              deletingDelay={50}
              pauseDelay={2000}
            />
            <p className="text-base md:text-[1.1rem] lg:text-xl font-normal leading-relaxed max-w-[600px] -mt-3 text-muted-foreground">
              {t.hero.subtitle}
            </p>
          </div>
        </div>
      </section>

      {/* nCare Logo Section */}
      <section id="sobre" className="bg-background py-16 md:py-32">
        <div className="container mx-auto px-6">
          <div className="max-w-5xl mx-auto">
            <div className="mb-12 md:mb-16 flex justify-center md:justify-start">
              <div className="w-full max-w-[280px] md:max-w-none">
                <AnimatedLogo />
              </div>
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-8 md:mb-12 text-foreground">{t.about.title}</h2>

            <div className="grid lg:grid-cols-2 gap-8 md:gap-12 text-lg md:text-xl leading-relaxed text-muted-foreground">
              <p>
                {t.about.paragraph1}
              </p>
              <p>
                {t.about.paragraph2}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Method and Tools Section */}
      <section id="metodo" className="bg-background py-16 md:py-32">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto space-y-16 md:space-y-32">
            {/* Method */}
            <div className="grid lg:grid-cols-2 gap-8 md:gap-16 items-start">
              <div>
                <div className="flex items-start gap-4 mb-6">
                  <span className="text-base md:text-lg text-muted-foreground font-mono">01.</span>
                  <h2 className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-foreground">{t.method.title1}</h2>
                </div>
              </div>
              <div>
                <p className="text-lg md:text-xl leading-relaxed text-muted-foreground">
                  {t.method.description1}
                </p>
              </div>
            </div>

            {/* Tools */}
            <div className="grid lg:grid-cols-2 gap-8 md:gap-16 items-start">
              <div className="lg:order-2">
                <div className="flex items-start gap-4 mb-6">
                  <span className="text-base md:text-lg text-muted-foreground font-mono">02.</span>
                  <h2 className="text-3xl md:text-4xl lg:text-5xl font-extrabold text-foreground">{t.method.title2}</h2>
                </div>
              </div>
              <div className="lg:order-1">
                <p className="text-lg md:text-xl leading-relaxed text-muted-foreground">
                  {t.method.description2}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Principles Section */}
      <section id="principios" className="bg-background py-16 md:py-32">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-8 lg:gap-16 max-w-7xl mx-auto">
            {/* Title */}
            <div className="lg:w-1/3 lg:sticky lg:top-32 lg:self-start">
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground">{t.principles.title}</h2>
            </div>

            {/* Cards */}
            <div className="lg:w-2/3 space-y-6 md:space-y-8">
              <div className="p-6 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-foreground">{t.principles.independence.title}</h3>
                <p className="text-sm md:text-base leading-relaxed text-muted-foreground">
                  {t.principles.independence.description}
                </p>
              </div>

              <div className="p-6 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-foreground">{t.principles.knowledge.title}</h3>
                <p className="text-sm md:text-base leading-relaxed text-muted-foreground">
                  {t.principles.knowledge.description}
                </p>
              </div>

              <div className="p-6 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-foreground">{t.principles.transparency.title}</h3>
                <p className="text-sm md:text-base leading-relaxed text-muted-foreground">
                  {t.principles.transparency.description}
                </p>
              </div>

              <div className="p-6 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-foreground">{t.principles.personalization.title}</h3>
                <p className="text-sm md:text-base leading-relaxed text-muted-foreground">
                  {t.principles.personalization.description}
                </p>
              </div>

              <div className="p-6 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-foreground">{t.principles.innovation.title}</h3>
                <p className="text-sm md:text-base leading-relaxed text-muted-foreground">
                  {t.principles.innovation.description}
                </p>
              </div>

              <div className="p-6 md:p-8">
                <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-foreground">{t.principles.confidentiality.title}</h3>
                <p className="text-sm md:text-base leading-relaxed text-muted-foreground">
                  {t.principles.confidentiality.description}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Founders Section */}
      <section id="fundadores" className="bg-background py-16 md:py-32">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-12 md:mb-16 text-foreground">{t.team.founders}</h2>

          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8 md:gap-12">
              <div>
                <a 
                  href="https://www.linkedin.com/in/conradolimacfa/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block mb-4 aspect-square overflow-hidden rounded-2xl hover:opacity-90 transition-opacity cursor-pointer"
                >
                  <Image
                    src="/images/team/care_CL.webp"
                    alt="Conrado Lima"
                    width={400}
                    height={400}
                    className="w-full h-full object-cover"
                  />
                </a>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-1">Conrado Lima, CGA, CFA</h3>
                <p className="text-sm md:text-base text-muted-foreground">CIO</p>
              </div>

              <div>
                <a 
                  href="https://www.linkedin.com/in/martin-hauser-cfp%C2%AE-b3397841/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block mb-4 aspect-square overflow-hidden rounded-2xl hover:opacity-90 transition-opacity cursor-pointer"
                >
                  <Image
                    src="/images/team/care_MH.webp"
                    alt="Martin Hauser"
                    width={400}
                    height={400}
                    className="w-full h-full object-cover"
                  />
                </a>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-1">Martin Hauser, CFP®</h3>
                <p className="text-sm md:text-base text-muted-foreground">CEO</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section id="time" className="bg-background py-16 md:py-32">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-12 md:mb-16 text-foreground">{t.team.teamTitle}</h2>

          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 md:gap-12">
              <div>
                <a 
                  href="https://www.linkedin.com/in/jo%C3%A3o-victor-grandizoli-030434108/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block mb-4 aspect-square overflow-hidden rounded-2xl hover:opacity-90 transition-opacity cursor-pointer"
                >
                  <Image
                    src="/images/team/care_JV.webp"
                    alt="João Grandizoli"
                    width={400}
                    height={400}
                    className="w-full h-full object-cover"
                  />
                </a>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-1">João Grandizoli</h3>
                <p className="text-sm md:text-base text-muted-foreground">CTO</p>
              </div>

              <div>
                <a 
                  href="https://www.linkedin.com/in/rutasavignac/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block mb-4 aspect-square overflow-hidden rounded-2xl hover:opacity-90 transition-opacity cursor-pointer"
                >
                  <Image
                    src="/images/team/care_RS.webp"
                    alt="Ruta Savignac"
                    width={400}
                    height={400}
                    className="w-full h-full object-cover"
                  />
                </a>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-1">Ruta Savignac, CFP®, TEP®</h3>
                <p className="text-sm md:text-base text-muted-foreground">Managing Director Europe</p>
              </div>

              <div>
                <a 
                  href="https://www.linkedin.com/in/veronicasarmento/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block mb-4 aspect-square overflow-hidden rounded-2xl hover:opacity-90 transition-opacity cursor-pointer"
                >
                  <Image
                    src="/images/team/care_VS.webp"
                    alt="Veronica Sarmento"
                    width={400}
                    height={400}
                    className="w-full h-full object-cover"
                  />
                </a>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-1">Veronica Sarmento, CFP®</h3>
                <p className="text-sm md:text-base text-muted-foreground">Senior Relationship Manager</p>
              </div>

              <div>
                <a 
                  href="https://www.linkedin.com/in/gabibweiss/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block mb-4 aspect-square overflow-hidden rounded-2xl hover:opacity-90 transition-opacity cursor-pointer"
                >
                  <Image
                    src="/images/team/care_GW.webp"
                    alt="Gabriela Weiss"
                    width={400}
                    height={400}
                    className="w-full h-full object-cover"
                  />
                </a>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-1">Gabriela Weiss</h3>
                <p className="text-sm md:text-base text-muted-foreground">Social Media</p>
              </div>

              <div>
                <a 
                  href="https://www.linkedin.com/in/martinruhe/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="block mb-4 aspect-square overflow-hidden rounded-2xl hover:opacity-90 transition-opacity cursor-pointer"
                >
                  <Image
                    src="/images/team/care_MR.webp"
                    alt="Martin Ruhe"
                    width={400}
                    height={400}
                    className="w-full h-full object-cover"
                  />
                </a>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-1">Martin Ruhe</h3>
                <p className="text-sm md:text-base text-muted-foreground">{t.team.roles.investmentAdvisor}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-background py-16 md:py-32 border-t border-border">
        <div className="container mx-auto px-6">
          <div className="max-w-7xl mx-auto">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12 lg:gap-20">
              {/* Fale Conosco */}
              <div className="text-center md:text-left">
                <h3 className="text-2xl md:text-2xl font-bold mb-6 md:mb-8 text-foreground">{t.contact.title}</h3>
                <div className="space-y-3 md:space-y-4 text-base md:text-lg">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{t.contact.phone}</p>
                    <a 
                      href={`https://wa.me/${t.contact.phoneNumber.replace(/[\s+-]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {t.contact.phoneNumber}
                    </a>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">{t.contact.email}</p>
                    <a 
                      href={`mailto:${t.contact.emailAddress}`}
                      className="block text-muted-foreground hover:text-foreground transition-colors break-all"
                    >
                      {t.contact.emailAddress}
                    </a>
                  </div>
                  <a 
                    href="https://www.instagram.com/care_mfo/" 
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center md:justify-start gap-2 text-muted-foreground hover:text-foreground transition-colors pt-2"
                  >
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="24" 
                      height="24" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                      className="w-5 h-5"
                    >
                      <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                    </svg>
                    care_mfo
                  </a>
                </div>
              </div>

              {/* Endereço */}
              <div className="text-center md:text-left">
                <h3 className="text-2xl md:text-2xl font-bold mb-6 md:mb-8 text-foreground">{t.contact.address}</h3>
                <a 
                  href={language === 'pt' 
                    ? "https://www.google.com/maps/search/?api=1&query=Av.+das+Nações+Unidas,+12399+-+Cj.+129+A,+Cidade+Monções,+São+Paulo+-+SP,+04578-000"
                    : "https://www.google.com/maps/search/?api=1&query=Rue+de+la+Corraterie+14,+1204+Geneva,+Switzerland"
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block space-y-1 md:space-y-2 text-base md:text-lg text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                >
                  {t.contact.building && <p>{t.contact.building}</p>}
                  <p>{t.contact.street}</p>
                  {t.contact.suite && <p>{t.contact.suite}</p>}
                  <p>{t.contact.city}</p>
                  <p>{t.contact.zipcode}</p>
                </a>
              </div>

              {/* Documentos */}
              <div className="text-center md:text-left">
                <h3 className="text-2xl md:text-2xl font-bold mb-6 md:mb-8 text-foreground">{t.contact.documents}</h3>
                <div className="space-y-6 md:space-y-8">
                  <a 
                    href="/documents/formulario_referencia_2025.pdf" 
                    download="Formulario_Referencia_Care_2025.pdf"
                    className="block text-base md:text-lg text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {t.contact.formReference}
                  </a>
                  
                  {/* Empresa Credenciada CVM */}
                  <div className="pt-4 border-t border-border">
                    <p className="text-sm md:text-base text-muted-foreground mb-3">
                      {t.contact.accredited}
                    </p>
                    <img
                      src="/images/logo-cvm.png"
                      alt="CVM - Comissão de Valores Mobiliários"
                      className="h-10 md:h-12 w-auto mx-auto md:mx-0"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background py-8 md:py-12">
        <div className="container mx-auto px-6">
          <p className="text-xs md:text-sm text-muted-foreground flex flex-wrap items-center gap-2">
            © 2025
            <img
              src="/images/ncare-footer-logo.svg"
              alt="nCare"
              className="h-4 md:h-5 w-auto inline-block"
            />
            {t.footer.rights}
          </p>
        </div>
      </footer>
    </main>
  )
}
