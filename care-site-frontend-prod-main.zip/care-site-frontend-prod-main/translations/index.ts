export const translations = {
  pt: {
    nav: {
      about: 'Sobre nós',
      method: 'Método',
      principles: 'Princípios',
      team: 'Time'
    },
    hero: {
      title1: 'Cuidamos',
      phrases: ['dos seus investimentos', 'do seu futuro', 'de você'],
      subtitle: 'Somos um multi-family office que cuida do que realmente importa. Com estratégia e humanidade.'
    },
    about: {
      title: 'Origem do nosso nome',
      paragraph1: 'Inspirados em fundar um escritório com abordagem além dos investimentos, englobando todos os serviços e soluções de gestão patrimonial, nossa razão de existir foi o cuidado.',
      paragraph2: 'Enxergamos nosso trabalho como algo similar ao da saúde: destilando informações complexas e transformando-as em decisões que se moldam a cada pessoa.'
    },
    method: {
      title1: 'Nosso método',
      description1: 'Nosso método é baseado em princípios sólidos e estratégias personalizadas para atender às necessidades de cada cliente. Trabalhamos com uma abordagem holística para garantir resultados consistentes e sustentáveis.',
      title2: 'Nossas ferramentas',
      description2: 'Utilizamos fundamentos baseados em experiências profissionais de quase meio século. O resultado é uma metodologia que permite liquidez, flexibilidade e longevidade aos nossos clientes.'
    },
    principles: {
      title: 'Princípios',
      independence: {
        title: 'Independência',
        description: 'Nossa estrutura independente nos permite oferecer soluções verdadeiramente personalizadas, livres de conflitos de interesse ou pressões comerciais.'
      },
      knowledge: {
        title: 'Conhecimento',
        description: 'Investimos continuamente em capacitação e tecnologia para entregar as melhores soluções do mercado aos nossos clientes.'
      },
      transparency: {
        title: 'Transparência',
        description: 'Mantemos uma comunicação clara e objetiva, garantindo que nossos clientes compreendam completamente cada aspecto de sua gestão patrimonial.'
      },
      personalization: {
        title: 'Personalização',
        description: 'Cada cliente é único. Por isso, desenvolvemos estratégias exclusivas que se adaptam aos objetivos e necessidades específicas de cada família.'
      },
      innovation: {
        title: 'Inovação',
        description: 'Buscamos constantemente novas tecnologias e metodologias para aprimorar nossa gestão e oferecer soluções mais eficientes aos nossos clientes.'
      },
      confidentiality: {
        title: 'Confidencialidade',
        description: 'Mantemos o mais alto padrão de sigilo e segurança com as informações de nossos clientes, garantindo total privacidade em todas as interações.'
      }
    },
    team: {
      founders: 'Founders',
      teamTitle: 'Time',
      roles: {
        investmentAdvisor: 'Consultor de Investimentos'
      }
    },
    contact: {
      title: 'Fale conosco:',
      address: 'Endereço:',
      documents: 'Documentos:',
      formReference: 'Formulário de Referência',
      accredited: 'Empresa Credenciada',
      building: 'Edifício Landmark',
      street: 'Av. das Nações Unidas, 12399',
      suite: 'Cj. 129 A',
      city: 'Cidade Monções, São Paulo - SP',
      zipcode: '04578-000',
      phone: 'Telefone:',
      email: 'Email:',
      phoneNumber: '+55 11 93473-1800',
      emailAddress: 'contato@caremfo.com'
    },
    footer: {
      rights: 'Todos os direitos reservados.'
    }
  },
  en: {
    nav: {
      about: 'About Us',
      method: 'Method',
      principles: 'Principles',
      team: 'Team'
    },
    hero: {
      title1: 'We care',
      phrases: ['for your investments', 'for your future', 'We stand by you'],
      subtitle: 'We are a multi-family office that cares for what truly matters. With strategy and humanity.'
    },
    about: {
      title: 'The Origin of Our Name',
      paragraph1: 'Inspired to establish an office with an approach beyond investments, encompassing all wealth management services and solutions, our reason for being was care.',
      paragraph2: 'We see our work as similar to healthcare: distilling complex information and transforming it into decisions tailored to each individual.'
    },
    method: {
      title1: 'Our Method',
      description1: 'Our method is based on solid principles and personalized strategies to meet the needs of each client. We work with a holistic approach to ensure consistent and sustainable results.',
      title2: 'Our Tools',
      description2: 'We use fundamentals based on nearly half a century of professional experience. The result is a methodology that provides liquidity, flexibility, and longevity to our clients.'
    },
    principles: {
      title: 'Principles',
      independence: {
        title: 'Independence',
        description: 'Our independent structure allows us to offer truly personalized solutions, free from conflicts of interest or commercial pressures.'
      },
      knowledge: {
        title: 'Knowledge',
        description: 'We continuously invest in training and technology to deliver the best market solutions to our clients.'
      },
      transparency: {
        title: 'Transparency',
        description: 'We maintain clear and objective communication, ensuring our clients fully understand every aspect of their wealth management.'
      },
      personalization: {
        title: 'Personalization',
        description: 'Every client is unique. That\'s why we develop exclusive strategies that adapt to the specific goals and needs of each family.'
      },
      innovation: {
        title: 'Innovation',
        description: 'We constantly seek new technologies and methodologies to enhance our management and offer more efficient solutions to our clients.'
      },
      confidentiality: {
        title: 'Confidentiality',
        description: 'We maintain the highest standards of confidentiality and security with our clients\' information, ensuring complete privacy in all interactions.'
      }
    },
    team: {
      founders: 'Founders',
      teamTitle: 'Team',
      roles: {
        investmentAdvisor: 'Financial Advisor'
      }
    },
    contact: {
      title: 'Contact Us:',
      address: 'Address:',
      documents: 'Documents:',
      formReference: 'Reference Form',
      accredited: 'Accredited Company',
      building: '',
      street: 'Rue de la Corraterie 14',
      suite: '',
      city: '1204 Geneva',
      zipcode: 'Switzerland',
      phone: 'Phone:',
      email: 'Email:',
      phoneNumber: '+41 79 549 17 98',
      emailAddress: 'contato@caremfo.com'
    },
    footer: {
      rights: 'All rights reserved.'
    }
  }
}

export type TranslationKey = keyof typeof translations.pt
