"use client"

import { useState, useEffect } from "react"

interface TypewriterProps {
  phrases: string[]
  typingDelay?: number
  deletingDelay?: number
  pauseDelay?: number
  className?: string
}

export function Typewriter({
  phrases,
  typingDelay = 100,
  deletingDelay = 50,
  pauseDelay = 2000,
  className = "",
}: TypewriterProps) {
  const [displayText, setDisplayText] = useState("")
  const [phraseIndex, setPhraseIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isPaused, setIsPaused] = useState(false)

  // Reset when phrases change (language switch)
  useEffect(() => {
    setDisplayText("")
    setPhraseIndex(0)
    setIsDeleting(false)
    setIsPaused(false)
  }, [phrases])

  useEffect(() => {
    const currentPhrase = phrases[phraseIndex]

    if (isPaused) {
      const pauseTimeout = setTimeout(() => {
        setIsPaused(false)
        setIsDeleting(true)
      }, pauseDelay)
      return () => clearTimeout(pauseTimeout)
    }

    if (isDeleting) {
      if (displayText.length === 0) {
        setIsDeleting(false)
        setPhraseIndex((prev) => (prev + 1) % phrases.length)
        return
      }

      const timeout = setTimeout(() => {
        setDisplayText((prev) => prev.slice(0, -1))
      }, deletingDelay)

      return () => clearTimeout(timeout)
    }

    if (displayText.length < currentPhrase.length) {
      const timeout = setTimeout(() => {
        setDisplayText((prev) => prev + currentPhrase[prev.length])
      }, typingDelay)

      return () => clearTimeout(timeout)
    } else {
      setIsPaused(true)
    }
  }, [displayText, phraseIndex, isDeleting, isPaused, phrases, typingDelay, deletingDelay, pauseDelay])

  return (
    <span className={className}>
      {displayText}
      <span className="inline-block h-[1em] border-l-2 border-current ml-0.5 align-middle animate-blink" />
    </span>
  )
}
