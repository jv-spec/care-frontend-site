'use client'

import { useState } from 'react'
import { useLanguage } from '@/contexts/LanguageContext'
import { translations } from '@/translations'
import { LanguageSwitcher } from './language-switcher'

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false)
  const { language } = useLanguage()
  const t = translations[language]

  const toggleMenu = () => setIsOpen(!isOpen)

  const handleLinkClick = () => {
    setIsOpen(false)
  }

  return (
    <>
      {/* Mobile Language Switcher & Hamburger */}
      <div className="md:hidden flex items-center gap-4">
        <LanguageSwitcher />
        
        {/* Hamburger Button */}
        <button
          onClick={toggleMenu}
          className="z-50 relative w-10 h-10 flex flex-col justify-center items-center"
          aria-label="Menu"
        >
          <span
            className={`w-6 h-0.5 bg-foreground transition-all duration-300 ${
              isOpen ? 'rotate-45 translate-y-1.5' : ''
            }`}
          />
          <span
            className={`w-6 h-0.5 bg-foreground transition-all duration-300 mt-1.5 ${
              isOpen ? 'opacity-0' : ''
            }`}
          />
          <span
            className={`w-6 h-0.5 bg-foreground transition-all duration-300 mt-1.5 ${
              isOpen ? '-rotate-45 -translate-y-2' : ''
            }`}
          />
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-background/95 backdrop-blur-sm z-40 md:hidden"
          onClick={toggleMenu}
        >
          <nav className="flex flex-col items-center justify-center h-full gap-8">
            <a
              href="#sobre"
              onClick={handleLinkClick}
              className="text-2xl font-medium text-foreground hover:text-foreground/70 transition-colors"
            >
              {t.nav.about}
            </a>
            <a
              href="#metodo"
              onClick={handleLinkClick}
              className="text-2xl font-medium text-foreground hover:text-foreground/70 transition-colors"
            >
              {t.nav.method}
            </a>
            <a
              href="#principios"
              onClick={handleLinkClick}
              className="text-2xl font-medium text-foreground hover:text-foreground/70 transition-colors"
            >
              {t.nav.principles}
            </a>
            <a
              href="#fundadores"
              onClick={handleLinkClick}
              className="text-2xl font-medium text-foreground hover:text-foreground/70 transition-colors"
            >
              {t.nav.team}
            </a>
          </nav>
        </div>
      )}
    </>
  )
}
