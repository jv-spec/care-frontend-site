"use client"

import { useLanguage } from '@/contexts/LanguageContext'
import { useEffect, useState } from 'react'

export function LanguageSwitcher() {
  const [mounted, setMounted] = useState(false)
  const { language, setLanguage } = useLanguage()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="flex items-center gap-2 opacity-0">
        <span className="text-sm md:text-base font-medium">PT</span>
        <span className="text-muted-foreground">|</span>
        <span className="text-sm md:text-base font-medium">EN</span>
      </div>
    )
  }

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={() => setLanguage('pt')}
        className={`text-sm md:text-base font-medium transition-colors ${
          language === 'pt'
            ? 'text-foreground'
            : 'text-muted-foreground hover:text-foreground'
        }`}
        aria-label="Português"
      >
        PT
      </button>
      <span className="text-muted-foreground">|</span>
      <button
        onClick={() => setLanguage('en')}
        className={`text-sm md:text-base font-medium transition-colors ${
          language === 'en'
            ? 'text-foreground'
            : 'text-muted-foreground hover:text-foreground'
        }`}
        aria-label="English"
      >
        EN
      </button>
    </div>
  )
}
