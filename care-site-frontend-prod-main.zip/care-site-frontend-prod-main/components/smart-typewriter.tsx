"use client"

import { useState, useEffect } from "react"

interface SmartTypewriterProps {
  phrases: string[]
  fixedTitle: string
  typingDelay?: number
  deletingDelay?: number
  pauseDelay?: number
}

export function SmartTypewriter({
  phrases,
  fixedTitle,
  typingDelay = 100,
  deletingDelay = 50,
  pauseDelay = 2000,
}: SmartTypewriterProps) {
  const [displayText, setDisplayText] = useState("")
  const [phraseIndex, setPhraseIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isPaused, setIsPaused] = useState(false)

  const currentPhrase = phrases[phraseIndex]
  const isStandalone = currentPhrase.toLowerCase().startsWith('we stand by')

  // Reset when phrases change (language switch)
  useEffect(() => {
    setDisplayText("")
    setPhraseIndex(0)
    setIsDeleting(false)
    setIsPaused(false)
  }, [phrases])

  useEffect(() => {
    if (isPaused) {
      const pauseTimeout = setTimeout(() => {
        setIsPaused(false)
        setIsDeleting(true)
      }, pauseDelay)
      return () => clearTimeout(pauseTimeout)
    }

    if (isDeleting) {
      if (displayText.length === 0) {
        setIsDeleting(false)
        setPhraseIndex((prev) => (prev + 1) % phrases.length)
        return
      }

      const timeout = setTimeout(() => {
        setDisplayText((prev) => prev.slice(0, -1))
      }, deletingDelay)

      return () => clearTimeout(timeout)
    }

    if (displayText.length < currentPhrase.length) {
      const timeout = setTimeout(() => {
        setDisplayText((prev) => prev + currentPhrase[prev.length])
      }, typingDelay)

      return () => clearTimeout(timeout)
    } else {
      setIsPaused(true)
    }
  }, [displayText, phraseIndex, isDeleting, isPaused, phrases, currentPhrase, typingDelay, deletingDelay, pauseDelay])

  return (
    <h1 className="text-[2rem] md:text-[2.5rem] lg:text-6xl leading-[1.1] mb-5 min-h-[3em] md:min-h-[3.5em]">
      {!isStandalone && (
        <span className="block font-medium">{fixedTitle}</span>
      )}
      <span className="block font-extrabold">
        {displayText}
        <span className="inline-block h-[1em] border-l-2 border-current ml-0.5 align-middle animate-blink" />
      </span>
    </h1>
  )
}
