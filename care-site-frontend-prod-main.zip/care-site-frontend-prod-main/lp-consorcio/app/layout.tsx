import type React from "react"
import type { Metadata } from "next"
import { Montserrat } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const montserrat = Montserrat({
  subsets: ["latin"],
  variable: "--font-montserrat",
})

export const metadata: Metadata = {
  title: "Análise de Carta de Consórcio | Care Multi-Family Office",
  description:
    "Análise especializada e imparcial de cartas de consórcio. Tome decisões mais seguras e estratégicas com o diagnóstico técnico de alto nível da Care MFO.",
  generator: "v0.app",
  openGraph: {
    title: "Análise de Carta de Consórcio | Care Multi-Family Office",
    description: "Análise especializada e imparcial de cartas de consórcio. Tome decisões mais seguras e estratégicas.",
    type: "website",
    url: "https://www.caremfo.com",
  },
}

export const viewport = {
  themeColor: "#0A0A0A",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <body className={`${montserrat.className} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
