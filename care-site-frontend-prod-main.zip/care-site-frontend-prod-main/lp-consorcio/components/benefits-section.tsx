import { Search, TrendingUp, AlertTriangle, Target, BarChart3, Lightbulb } from "lucide-react"

const benefits = [
  {
    icon: Search,
    title: "Estrutura do Grupo",
    description: "Análise detalhada da composição, tamanho e comportamento do grupo de consórcio.",
  },
  {
    icon: TrendingUp,
    title: "Histórico de Contemplações",
    description: "Avaliação do padrão de contemplações para prever suas chances reais.",
  },
  {
    icon: BarChart3,
    title: "Taxas Envolvidas",
    description: "Mapeamento completo de todas as taxas, custos e encargos da sua carta.",
  },
  {
    icon: AlertTriangle,
    title: "Identificação de Riscos",
    description: "Pontos críticos que normalmente passam despercebidos até por investidores experientes.",
  },
  {
    icon: Target,
    title: "Projeções de Prazo",
    description: "Estimativas realistas de quando você pode ser contemplado.",
  },
  {
    icon: Lightbulb,
    title: "Oportunidades",
    description: "Identificação de estratégias para otimizar seu investimento em consórcio.",
  },
]

export function BenefitsSection() {
  return (
    <section id="beneficios" className="py-20 lg:py-32 bg-card/50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-sm font-medium text-care-copper mb-4">O Que Você Recebe</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-care-light mb-6 text-balance">
            Uma Leitura Completa da Sua Carta de Consórcio
          </h2>
          <p className="text-care-gray text-lg">
            Nossa avaliação oferece profundidade técnica e clareza para você tomar a melhor decisão sobre seu
            investimento.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="group p-6 rounded-xl bg-card border border-border hover:border-care-copper/50 transition-all duration-300"
            >
              <div className="mb-4 p-3 rounded-lg bg-care-copper/10 w-fit group-hover:bg-care-copper/20 transition-colors">
                <benefit.icon className="h-6 w-6 text-care-copper" />
              </div>
              <h3 className="text-lg font-semibold text-care-light mb-2">{benefit.title}</h3>
              <p className="text-care-gray text-sm leading-relaxed">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
