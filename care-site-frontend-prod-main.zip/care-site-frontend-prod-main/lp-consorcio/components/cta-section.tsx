import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export function CTASection() {
  return (
    <section className="py-20 lg:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl bg-card border border-care-copper/20 overflow-hidden">
          {/* Background effects */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-care-copper/50 to-transparent" />
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-80 h-80 bg-care-copper/10 rounded-full blur-3xl" />

          <div className="relative px-6 py-16 lg:py-24 text-center">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-care-light mb-6 max-w-3xl mx-auto text-balance">
              Transforme Dúvidas em <span className="text-care-copper">Decisões Inteligentes</span>
            </h2>
            <p className="text-lg text-care-gray max-w-2xl mx-auto mb-10">
              Se você busca segurança, assertividade e um diagnóstico técnico de alto nível antes de avançar com sua
              carta de consórcio, este é o caminho mais confiável.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-care-copper hover:bg-care-bronze text-background font-semibold px-8"
              >
                <Link href="https://caremfo.typeform.com/consorcio" target="_blank">
                  Solicitar Análise por R$ 499
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>
            <p className="text-sm text-care-gray mt-6">
              ⏱ Entrega em até 48 horas • 🔒 Produto exclusivo Care Multi-Family Office
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
