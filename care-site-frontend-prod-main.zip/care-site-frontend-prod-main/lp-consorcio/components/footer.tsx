import Link from "next/link"

export function Footer() {
  return (
    <footer className="py-12 border-t border-border">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <span className="text-xl font-semibold text-care-light">Care</span>
            <span className="text-sm text-care-gray">Multi-Family Office</span>
          </div>

          <nav className="flex items-center gap-6">
            <Link
              href="https://www.caremfo.com"
              target="_blank"
              className="text-sm text-care-gray hover:text-care-light transition-colors"
            >
              Site Principal
            </Link>
            <Link href="#beneficios" className="text-sm text-care-gray hover:text-care-light transition-colors">
              Benefícios
            </Link>
            <Link href="#preco" className="text-sm text-care-gray hover:text-care-light transition-colors">
              Investimento
            </Link>
          </nav>

          <p className="text-sm text-care-gray">
            © {new Date().getFullYear()} Care Multi-Family Office. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
