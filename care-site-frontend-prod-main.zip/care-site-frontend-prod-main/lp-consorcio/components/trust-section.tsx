import { Award, Users, TrendingUp, Lock } from "lucide-react"

const stats = [
  {
    icon: Users,
    value: "+20",
    label: "Anos de Experiência",
    description: "No mercado financeiro e planejamento patrimonial",
  },
  {
    icon: TrendingUp,
    value: "100%",
    label: "Imparcialidade",
    description: "Sem conflito de interesse ou comissões",
  },
  {
    icon: Award,
    value: "Exclusivo",
    label: "Algoritmo Proprietário",
    description: "Desenvolvido internamente pela Care",
  },
  {
    icon: Lock,
    value: "Total",
    label: "Confidencialidade",
    description: "Seus dados protegidos com sigilo absoluto",
  },
]

export function TrustSection() {
  return (
    <section className="py-20 lg:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-sm font-medium text-care-copper mb-4">Por que a Care?</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-care-light mb-6 text-balance">
            Tecnologia e Expertise em Uma Única Solução
          </h2>
          <p className="text-care-gray text-lg">
            Nosso algoritmo proprietário, somado ao olhar consultivo da Care, garante uma interpretação precisa, isenta
            e orientada à tomada de decisão.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div key={index} className="text-center p-6 rounded-xl bg-card border border-border">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-care-copper/10 mb-4">
                <stat.icon className="h-6 w-6 text-care-copper" />
              </div>
              <p className="text-3xl font-bold text-care-copper mb-1">{stat.value}</p>
              <p className="text-sm font-medium text-care-light mb-2">{stat.label}</p>
              <p className="text-xs text-care-gray">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
