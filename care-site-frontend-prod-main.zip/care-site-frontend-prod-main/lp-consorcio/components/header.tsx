import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link href="https://www.caremfo.com" className="flex items-center gap-3">
            <Image
              src="/images/care-logo.png"
              alt="Care Multi-Family Office"
              width={32}
              height={32}
              className="invert"
            />
            <div className="flex flex-col">
              <span className="text-lg font-semibold text-care-light leading-tight">Care</span>
              <span className="text-xs text-care-gray leading-tight">Multi-Family Office</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <Link href="#beneficios" className="text-sm text-care-gray hover:text-care-light transition-colors">
              Benefícios
            </Link>
            <Link href="#como-funciona" className="text-sm text-care-gray hover:text-care-light transition-colors">
              Como Funciona
            </Link>
            <Link href="#preco" className="text-sm text-care-gray hover:text-care-light transition-colors">
              Investimento
            </Link>
            <Link href="#faq" className="text-sm text-care-gray hover:text-care-light transition-colors">
              Dúvidas
            </Link>
          </nav>

          <Button asChild className="bg-care-copper hover:bg-care-bronze text-background font-medium">
            <Link href="#preco">Solicitar Análise</Link>
          </Button>
        </div>
      </div>
    </header>
  )
}
