import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const faqs = [
  {
    question: "O que é a Análise de Carta de Consórcio?",
    answer:
      "É uma avaliação técnica e imparcial que examina todos os aspectos da sua carta de consórcio: estrutura do grupo, histórico de contemplações, taxas, riscos, oportunidades e projeções de prazo. O objetivo é fornecer clareza para você tomar a melhor decisão sobre seu investimento.",
  },
  {
    question: "Como funciona o algoritmo proprietário?",
    answer:
      "Nosso algoritmo foi desenvolvido internamente por profissionais com mais de 20 anos de experiência no mercado financeiro. Ele processa dados históricos, padrões de contemplação, estrutura de taxas e outras variáveis para gerar insights precisos sobre sua carta.",
  },
  {
    question: "Quanto tempo leva para receber a análise?",
    answer:
      "O prazo máximo de entrega é de 48 horas após o recebimento de todos os documentos necessários. Na maioria dos casos, entregamos antes desse prazo.",
  },
  {
    question: "A análise é realmente imparcial?",
    answer:
      "Sim, absolutamente. A Care Multi-Family Office não vende consórcios nem recebe comissões de administradoras. Nossa única fonte de receita neste produto é a própria análise, garantindo total isenção na avaliação.",
  },
  {
    question: "Que documentos preciso enviar?",
    answer:
      "Você precisará enviar o contrato do consórcio, extratos recentes do grupo, e qualquer documentação adicional fornecida pela administradora. Orientamos você sobre exatamente o que é necessário após a contratação.",
  },
  {
    question: "Posso tirar dúvidas após receber o relatório?",
    answer:
      "Sim! Oferecemos suporte pós-entrega para esclarecer qualquer dúvida sobre o relatório e ajudar você a interpretar os resultados para sua tomada de decisão.",
  },
]

export function FAQSection() {
  return (
    <section id="faq" className="py-20 lg:py-32 bg-card/50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-sm font-medium text-care-copper mb-4">Dúvidas Frequentes</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-care-light mb-6">Perguntas e Respostas</h2>
          <p className="text-care-gray text-lg">Tire suas principais dúvidas sobre nossa análise de consórcio.</p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card border border-border rounded-lg px-6 data-[state=open]:border-care-copper/50"
              >
                <AccordionTrigger className="text-left text-care-light hover:text-care-copper hover:no-underline py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-care-gray pb-5">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}
