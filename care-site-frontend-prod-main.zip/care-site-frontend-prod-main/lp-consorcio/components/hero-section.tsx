import { Button } from "@/components/ui/button"
import { ArrowRight, Shield, Clock, FileCheck } from "lucide-react"
import Link from "next/link"

export function HeroSection() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-care-copper/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-care-slate/10 rounded-full blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-care-copper/10 border border-care-copper/20">
              <span className="w-2 h-2 rounded-full bg-care-copper animate-pulse" />
              <span className="text-sm text-care-tan">Produto Exclusivo Care MFO</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-care-light leading-tight text-balance">
              Análise Especializada de <span className="text-care-copper">Carta de Consórcio</span>
            </h1>

            <p className="text-lg text-care-gray max-w-xl leading-relaxed">
              Tome decisões mais seguras e estratégicas no universo de consórcios. Nossa análise imparcial oferece uma
              leitura completa da sua carta com profundidade técnica e clareza.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                asChild
                size="lg"
                className="bg-care-copper hover:bg-care-bronze text-background font-semibold px-8"
              >
                <Link href="https://caremfo.typeform.com/consorcio" target="_blank">
                  Solicitar Análise
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-care-slate text-care-light hover:bg-care-slate/20 bg-transparent"
              >
                <Link href="#como-funciona">Como Funciona</Link>
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-border">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-care-copper/10">
                  <Shield className="h-5 w-5 text-care-copper" />
                </div>
                <div>
                  <p className="text-sm font-medium text-care-light">Imparcial</p>
                  <p className="text-xs text-care-gray">Sem conflito</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-care-copper/10">
                  <Clock className="h-5 w-5 text-care-copper" />
                </div>
                <div>
                  <p className="text-sm font-medium text-care-light">48 horas</p>
                  <p className="text-xs text-care-gray">Prazo máximo</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-care-copper/10">
                  <FileCheck className="h-5 w-5 text-care-copper" />
                </div>
                <div>
                  <p className="text-sm font-medium text-care-light">Completa</p>
                  <p className="text-xs text-care-gray">360° da carta</p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative lg:pl-8">
            <div className="relative aspect-square max-w-md mx-auto">
              {/* Decorative rings */}
              <div className="absolute inset-0 rounded-full border border-care-slate/20" />
              <div className="absolute inset-8 rounded-full border border-care-copper/20" />
              <div className="absolute inset-16 rounded-full border border-care-tan/30" />

              {/* Center content */}
              <div className="absolute inset-24 rounded-full bg-card flex items-center justify-center">
                <div className="text-center">
                  <p className="text-4xl font-bold text-care-copper">R$ 499</p>
                  <p className="text-sm text-care-gray mt-1">Investimento único</p>
                </div>
              </div>

              {/* Floating badges */}
              <div className="absolute top-8 right-8 px-4 py-2 rounded-lg bg-card border border-border shadow-lg">
                <p className="text-xs text-care-gray">Algoritmo</p>
                <p className="text-sm font-medium text-care-light">Proprietário</p>
              </div>
              <div className="absolute bottom-16 left-0 px-4 py-2 rounded-lg bg-card border border-border shadow-lg">
                <p className="text-xs text-care-gray">Experiência</p>
                <p className="text-sm font-medium text-care-light">+20 anos</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
