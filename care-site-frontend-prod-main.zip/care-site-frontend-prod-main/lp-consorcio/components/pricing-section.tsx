import { Button } from "@/components/ui/button"
import { Check, Clock, Shield } from "lucide-react"
import Link from "next/link"

const features = [
  "Análise completa da estrutura do grupo",
  "Histórico detalhado de contemplações",
  "Mapeamento de todas as taxas e custos",
  "Identificação de riscos ocultos",
  "Projeções realistas de prazo",
  "Identificação de oportunidades",
  "Relatório em PDF profissional",
  "Suporte pós-entrega para dúvidas",
]

export function PricingSection() {
  return (
    <section id="preco" className="py-20 lg:py-32 bg-card/50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-sm font-medium text-care-copper mb-4">Investimento</p>
          <h2 className="text-3xl sm:text-4xl font-bold text-care-light mb-6">Clareza que Vale Cada Centavo</h2>
          <p className="text-care-gray text-lg">
            Um pequeno investimento que pode evitar decisões equivocadas e economizar milhares de reais.
          </p>
        </div>

        <div className="max-w-lg mx-auto">
          <div className="relative rounded-2xl bg-card border border-care-copper/30 overflow-hidden">
            {/* Glow effect */}
            <div className="absolute -top-20 -right-20 w-40 h-40 bg-care-copper/20 rounded-full blur-3xl" />

            <div className="relative p-8 lg:p-10">
              <div className="flex items-baseline justify-center gap-2 mb-2">
                <span className="text-5xl lg:text-6xl font-bold text-care-copper">R$ 499</span>
              </div>
              <p className="text-center text-care-gray mb-8">Investimento único</p>

              <div className="grid sm:grid-cols-2 gap-x-6 gap-y-4 mb-8">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="flex-shrink-0 w-5 h-5 rounded-full bg-care-copper/20 flex items-center justify-center">
                      <Check className="h-3 w-3 text-care-copper" />
                    </div>
                    <span className="text-sm text-care-light">{feature}</span>
                  </div>
                ))}
              </div>

              <Button
                asChild
                size="lg"
                className="w-full bg-care-copper hover:bg-care-bronze text-background font-semibold text-lg py-6"
              >
                <Link href="https://caremfo.typeform.com/consorcio" target="_blank">
                  Solicitar Minha Análise
                </Link>
              </Button>

              <div className="flex items-center justify-center gap-6 mt-6 pt-6 border-t border-border">
                <div className="flex items-center gap-2 text-sm text-care-gray">
                  <Clock className="h-4 w-4 text-care-copper" />
                  <span>Entrega em até 48h</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-care-gray">
                  <Shield className="h-4 w-4 text-care-copper" />
                  <span>Análise imparcial</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
